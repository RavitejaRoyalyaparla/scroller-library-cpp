# Scroller Feed Library

This is a simple Python library for creating scroller feeds in Django projects.

## Installation

You can install the library via pip:

`sh
pip install scroller-feed

